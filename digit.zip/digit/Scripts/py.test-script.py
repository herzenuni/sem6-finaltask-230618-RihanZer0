#!r:\�����\third\prog\sem6\digit\scripts\python3.exe -x
# EASY-INSTALL-ENTRY-SCRIPT: 'pytest==3.6.2','console_scripts','py.test'
__requires__ = 'pytest==3.6.2'
import re
import sys
from pkg_resources import load_entry_point

if __name__ == '__main__':
    sys.argv[0] = re.sub(r'(-script\.pyw?|\.exe)?$', '', sys.argv[0])
    sys.exit(
        load_entry_point('pytest==3.6.2', 'console_scripts', 'py.test')()
    )
