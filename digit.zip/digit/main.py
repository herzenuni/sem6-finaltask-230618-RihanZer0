from tkinter import *
import functools
import pytest

def Reset():
    win.configure(text=GOH(int(SpinDIG.get()),z.get()))
    print(bind_bin(GOH)(int(SpinDIG.get())))

def GOH(spin, radio):
    if radio == 0:
        x = ['Zer0', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine']
        if spin > 9 or spin < 0:
            text = 'Наша "база" распологает названиями лишь от 0 до 9. Такого Задание...'
        else:
            text=x[spin]
    if radio == 2:
        if spin < 0:
            text=('-'+bin(spin)[3:])
        else:
            text = bin(spin)[2:]
    if radio == 8:
        if spin < 0:
            text = ('-' + oct(spin)[3:])
        else:
            text = oct(spin)[2:]
    if radio == 16:
        if spin < 0:
            text=('-'+hex(spin)[3:])
        else:
            text = hex(spin)[2:]
    return text

def bind_bin(func):
    @functools.wraps(func)
    def inner(*args, **kwargs):
        return func(args[0], 2)
    return inner

root = Tk()
root.geometry("500x225")
root.title("DiGiT")
Comic = "-family {Comic Sans MS} -size 13 -weight normal " \
            "-slant roman -underline 0 -overstrike 0"
z = IntVar()

SpinDIG = Spinbox(root, from_=0, to=9, width=45, font=Comic)
SpinDIG.place(relx=0.12, rely=0.18, relheight=0.08, relwidth=0.09)

Name = Radiobutton(root, text='''Name''', font=Comic, variable=z, value=0)
Name.place(relx=0.1, rely=0.3, relheight=0.16, relwidth=0.15)

Name2 = Radiobutton(root, text='''bin''', font=Comic, variable=z, value=2)
Name2.place(relx=0.077, rely=0.45, relheight=0.16, relwidth=0.15)

Name8 = Radiobutton(root, text='''oct''', font=Comic, variable=z, value=8)
Name8.place(relx=0.081, rely=0.6, relheight=0.16, relwidth=0.15)

Name16 = Radiobutton(root, text='''hex''', font=Comic, variable=z, value=16)
Name16.place(relx=0.081, rely=0.75, relheight=0.16, relwidth=0.15)

win = Message(root, width=290, text='''...''', font=Comic)
win.place(relx=0.38, rely=0.04, relheight=0.55, relwidth=0.58)

magic = Button(root, text='''DO IT!''', font=Comic, command=Reset)
magic.place(relx=0.6, rely=0.67, height=40, width=71)


root.mainloop()

if __name__ == '__main__':
    print('Удачно!')
@pytest.mark.parametrize("a,b,expected", [
    (2,0,'Two'),
    (11,0,'Наша "база" распологает названиями лишь от 0 до 9. Такого Задание...'),
    (-1,0,'Наша "база" распологает названиями лишь от 0 до 9. Такого Задание...'),
    (2,2,'10'),
    (8,8,'10'),
    (16,16,'10'),
    (-2,2,'-10'),
    (-8,8,'-10'),
    (-16,16,'-10')
])
def test_param(a, b, expected):
    assert GOH(a, b) == expected
